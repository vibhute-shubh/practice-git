import React, { useState } from 'react'
import './loginForm.css'
import 'bootstrap/dist/css/bootstrap.min.css'

function LoginForm() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [isEmailValid, setIsEmailValid] = useState(false);
  const [isPasswordValid, setIsPasswordValid] = useState(false);
  const [errors, setErrors] = useState({});

  let handleSubmit = (event) => {
    event.preventDefault();
    if (password !== confirmPassword) {
      setErrors({ confirmPassword: 'Passwords must match' });
    } else {
      alert("Form submitted");
    }
  };

  let handleEmailChange = (event) => {
    const emailValue = event.target.value;
    const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,3}$/;
    setEmail(emailValue);

    if (emailPattern.test(emailValue)) {
      setIsEmailValid(true);
    } else {
      setIsEmailValid(false);
    }
  }

  let handlePasswordChange = (event) => {
    const passwordValue = event.target.value;
    setPassword(passwordValue);

    if (passwordValue.length >= 8) {
      setIsPasswordValid(true);
    } else {
      setIsPasswordValid(false);
    }
  }

  return (
    <div className='wrapper bg-dark d-flex align-items-center justify-content-center w-100'>
      <div className='login rounded'>
        <h2 className='mb-3'>Enter login details</h2>
        <form onSubmit={handleSubmit}>
          <div className='form-group mb-4'>
            <label htmlFor='email' className='form-label'>Email address: </label>
            <input type="email" id="email" value={email} className='form-control'
              onChange={handleEmailChange} required />
              <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
            {isEmailValid ? null : <p className='alert alert-danger' role='alert'>Please enter a valid email</p>}
          </div>
          <div className='form-group mb-2'>
            <label htmlFor='password' className='form-label'>Password: </label>
            <input type="password" id="password" value={password} className='form-control'
              onChange={handlePasswordChange}
              onBlur={() => {
                if (password !== confirmPassword) setErrors({ confirmPassword: 'Passwords must be matched' });
                else setErrors({});
              }} required />
            {isPasswordValid ? null : <p className='alert alert-danger' role='alert'>Password must be at least 8 characters</p>}
            {errors.confirmPassword && (<span className='alert alert-danger' role='alert'>{errors.confirmPassword}</span>)}
          </div>
          <div className='form-group mb-2'>
            <label htmlFor='confirm_password' className='form-label'>Confirm password: </label>
            <input type="password" id="confirm_password" value={confirmPassword} className='form-control'
              onChange={(event) => setConfirmPassword(event.target.value)}
              minLength={8} required
              onBlur={() => {
                if (password !== confirmPassword) setErrors({ confirmPassword: 'Passwords must be matched' });
                else setErrors({});
              }} />
          </div>
          <div className='form-group form-check mb-2'>
            <input type="checkbox" className='form-check-input' />
            <label htmlFor='check' className='form-check-label'>Remeber login</label>
          </div>
          <button type="submit" className="btn btn-success mt-2" disabled={!isEmailValid || !isPasswordValid}>Sign-in</button>
        </form>
      </div>
    </div>
  )
}

export default LoginForm
