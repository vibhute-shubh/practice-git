import LoginForm from './LoginForm';
import './App.css';

function App() {
  return (
    <div className="App">
      <LoginForm />
    </div>
  );
}

export default App;
